package controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.model.ObjectMetadata;


import aws.AwsUploadUtility;


public class UploadFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	
	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		System.out.println("problem1");
		
		

			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			Iterator<FileItem> iterator = null;
			String documentType = null;
			InputStream fileIS=null;
			String filename=null;
			
			
			
			System.out.println("problem2");
			
			try {
			iterator = upload.parseRequest(request).iterator();
		
			

			while (iterator.hasNext()) {
				FileItem item = iterator.next();
				if (!item.isFormField()) {
				documentType=item.getContentType();
				fileIS=item.getInputStream();
				filename=item.getName();
				}
				}
			} catch (FileUploadException e) {
				
				e.printStackTrace();
				}

			System.out.println("problem3");
	
	System.out.println("=================" + fileIS);
			
	Properties prop = new Properties();

	InputStream propstream = new FileInputStream(getServletContext().getRealPath("WEB-INF/s3.properties"));
	prop.load(propstream);
	
	AWSCredentials credentials = new BasicAWSCredentials(
	prop.getProperty("AWSAccessKeyId"),
	prop.getProperty("AWSSecretKey"));
	String bucketName=prop.getProperty("bucketName");
	
	
	System.out.println("problem4");
	
	
	AwsUploadUtility s3client = new AwsUploadUtility();
	
	System.out.println("line 1");
	
	
	ObjectMetadata metadata=new ObjectMetadata();
	
	System.out.println("line 2");
	
	metadata.setContentLength(Long.valueOf(fileIS.available()));
	
	System.out.println("line 3");
	
	s3client.uploadfile(credentials, bucketName, filename, fileIS, metadata);
	
	System.out.println("line 4");
	
	response.sendRedirect("output.jsp");
	System.out.println("problem5");
	
	}

	}
